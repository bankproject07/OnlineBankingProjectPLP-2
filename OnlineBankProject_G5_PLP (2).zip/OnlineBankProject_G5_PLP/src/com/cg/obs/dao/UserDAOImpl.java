package com.cg.obs.dao;

import java.sql.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.obs.bean.AccountMaster;
import com.cg.obs.bean.Customer;
import com.cg.obs.bean.FundTransfer;
import com.cg.obs.bean.Payee;
import com.cg.obs.bean.RequestTable;
import com.cg.obs.bean.ServiceTracker;
import com.cg.obs.bean.Transactions;
import com.cg.obs.bean.Users;
import com.cg.obs.exception.UserException;


@Repository("userDao")
public class UserDAOImpl implements IUserDAO{

	@PersistenceContext
	private EntityManager entityManager;
	
	public UserDAOImpl() {
		// TODO Auto-generated constructor stub
	}
	
	
	public UserDAOImpl(EntityManager entityManager) {
		super();
		this.entityManager = entityManager;
	}



	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}




	@Override
	public Users getUser(int id) throws UserException {
		Users user=null;
	try{
			
			
			user=entityManager.find(Users.class,id);
		//	entityManager.flush();
			
		
		}
		catch(Exception e)
		{
		
			throw new UserException("exception occured:"+e.getMessage());
		}
		if(user==null)
		{
			throw new UserException("No User found with id="+id);
		}
	
		return user;
	}

	@Override
	public void registerUser(Users user) throws UserException {
		// TODO Auto-generated method stub
		
	}


		@Override
		public List<Transactions> getMiniTransactions(Long accountno) throws UserException {
			

			List<Transactions> transactions=null;
			try 
			{
				/*EntityTransaction transaction=entityManager.getTransaction();
				transaction.begin();*/
				System.out.println(accountno);
				String qStr="select t from Transactions t where t.accountID=:Account_ID  and ROWNUM <= 10";
				TypedQuery<Transactions> query=entityManager.createQuery(qStr,Transactions.class);
				query.setParameter("Account_ID",accountno);
				
				transactions=query.getResultList();
				System.out.println("mini transa dao:"+transactions);
			}
			catch (Exception e) 
			{
				throw new UserException(e.getMessage());
			}
			
			if(transactions==null || transactions.isEmpty())
			{
				throw new UserException("No transaction to display ");
			}
			return transactions;
			
			
		}
	

		@Override
		public List<Transactions> getDetailedTransactions(Long accountno,
				Date fromDate, Date toDate) throws UserException {


			List<Transactions> transactions=null;
			try 
			{
				/*EntityTransaction transaction=entityManager.getTransaction();
				transaction.begin();*/
				String qStr="select t from Transactions t where t.accountID=:Account_ID and t.dateOfTransaction between :startDate and :endDate";
				TypedQuery<Transactions> query=entityManager.createQuery(qStr,Transactions.class);
				query.setParameter("Account_ID",accountno);
				query.setParameter("startDate", fromDate );
				query.setParameter("endDate", toDate );
				
				transactions=query.getResultList();
			}
			catch (Exception e) 
			{
				throw new UserException(e.getMessage());
			}
			
			if(transactions==null || transactions.isEmpty())
			{
				throw new UserException("No transaction to display ");
			}
			return transactions;   
		}
		
	@Override
	public int getCustomerId(Long accountno) throws UserException {
		
		AccountMaster account;
		int customerId=-1;
		try 
		{
			
		account=entityManager.find(AccountMaster.class,accountno);
		System.out.println("acc in dao"+account);
		customerId=account.getCustomerId();
		System.out.println("in dao"+customerId);
		}
		catch (Exception e) 
		{
			throw new UserException(e.getMessage());
		}
		
		
		return customerId;
		
	}

	@Override
	public Customer getCustomer(int customerid) throws UserException {
		Customer customer=null;
		try
		{
			customer=entityManager.find(Customer.class, customerid);	
		} 

		catch(Exception e)
		{
			throw new UserException(e.getMessage());
		}
		
		if(customer==null)
		{
			throw new UserException("No  Customer found with "+customerid);
		}
		return  customer;
	}



	@Override
	public void updateCustomerDetails(Customer customer) throws UserException {
		

		try
		{
			entityManager.merge(customer);
			entityManager.flush();
			
		} 
		catch (Exception e)
		{
			throw new UserException(e.getMessage());
		}
		
		
	}


	@Override
	public int requestService(ServiceTracker services) throws UserException {
		
		return 0;
	}

	@Override
	public ServiceTracker getRequestedServiceList(int requestid)
			throws UserException {
		
		return null;
	}

	@Override
	public int fundTransfer(FundTransfer transferInfo) throws UserException {
	
		int fundTransferId=-1;
		try
		{
			entityManager.persist(transferInfo); 
			fundTransferId=transferInfo.getFundTransfer_Id();
			
			
		} 
		catch (Exception e)
		{
			throw new UserException(e.getMessage());
		}
		return fundTransferId;
	}

	@Override
	public void insertTransaction(Transactions transaction)
			throws UserException {

		try
		{
			entityManager.persist(transaction); 
			
		} 
		catch (Exception e)
		{
			throw new UserException(e.getMessage());
		}
		
		
	}


	@Override
	public void updateBalance(AccountMaster account) throws UserException {
		
		try
		{
			entityManager.persist(account); 
			
		} 
		catch (Exception e)
		{
			throw new UserException(e.getMessage());
		}
		
		
		
		
	}


	@Override
	public void updatePayeeBalance(double Updatedbalance, Long accountNo)
			throws UserException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void changePassword(Users user) throws UserException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateLockStatus(int userid) throws UserException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Payee> getPayee(long accountid) throws UserException {

		List<Payee> payeeList=null;
		try 
		{
			/*EntityTransaction transaction=entityManager.getTransaction();
			transaction.begin();*/
			System.out.println(accountid);
			String qStr="select payee from Payee payee where payee.accountno=:Account_No";
			TypedQuery<Payee> query=entityManager.createQuery(qStr,Payee.class);
			query.setParameter("Account_No",accountid);
			
			payeeList=query.getResultList();
			System.out.println("payeelist dao:"+payeeList);
		}
		catch (Exception e) 
		{
			throw new UserException(e.getMessage());
		}
		
		if(payeeList==null || payeeList.isEmpty())
		{
			throw new UserException("No transaction to display ");
		}
		return payeeList;
	}

	@Override
	public void insertPayee(Payee payee) throws UserException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isPayeeAccountExists(long payeeAccountNo)
			throws UserException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public AccountMaster getAccount(long accountno) {
		
		AccountMaster account=entityManager.find(AccountMaster.class, accountno);
		return account;
	}

	@Override
	public int registerUser(Users user, Customer customer) throws UserException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int addRequest(RequestTable resTab) throws UserException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public RequestTable getAccountId(int custId) throws UserException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int isCheckBookRequestExist(Long accountno) throws UserException {
		// TODO Auto-generated method stub
		return 0;
	}




	


	
}
