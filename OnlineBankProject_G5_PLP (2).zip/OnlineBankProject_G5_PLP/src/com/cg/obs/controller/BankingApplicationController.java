package com.cg.obs.controller;


import java.sql.Date;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


import com.cg.obs.bean.AccountMaster;
import com.cg.obs.bean.Customer;
import com.cg.obs.bean.FundTransfer;
import com.cg.obs.bean.Payee;
import com.cg.obs.bean.ServiceTracker;
import com.cg.obs.bean.Transactions;
import com.cg.obs.bean.Users;
import com.cg.obs.service.IUserService;



@Controller
public class BankingApplicationController {

	
	@Autowired
	IUserService userService;
	
	public BankingApplicationController() {
		// TODO Auto-generated constructor stub
	}

	public IUserService getUserService() {
		return userService;
	}

	public void setUserService(IUserService userService) {
		this.userService = userService;
	}

	public BankingApplicationController(IUserService userService) {
		super();
		this.userService = userService;
	}
	
	
	@RequestMapping("Login")
	public String getLoginPage(@RequestParam("username") int userId,@RequestParam("password") String password,Model model,HttpSession session){
		
		System.out.println(userId+" "+password);
		Users user=userService.getUser(userId);
		System.out.println(user);
		if(user!=null)
		{
			
			
		if(password.equalsIgnoreCase(user.getLoginPassword()))
		{
			System.out.println("user login success");
		      //model.addAttribute("accountno", user.getAccountId());
		session.setAttribute("accountno", user.getAccountId());
		session.setAttribute("userid", userId);
			return "index";
		}
		
		
	}
		model.addAttribute("errMsg", "Login error");
			return "pages/ErrorPage";
			
		
	
	}
	
	@RequestMapping("GetMiniTransactions")
	public String getMiniTransactionPage(Model model,HttpSession session){
		
		System.out.println(session.getAttribute("accountno"));
		Long accountno=(Long)session.getAttribute("accountno");
		//System.out.println(accid);
		//Long accountno=Long.parseLong(accid);
		List<Transactions> miniTransList=userService.getMiniTransactions(accountno);
		System.out.println(miniTransList);
		model.addAttribute("miniTrasactionList",miniTransList);
		
		return "pages/MiniTransactions";
	}
	
	@RequestMapping("GetDetailedTransactions")
	public String getDetailedTransactionsPage(@RequestParam("fromDate") Date fromDate,@RequestParam("toDate") Date toDate,Model model,HttpSession session) {
		
		System.out.println(session.getAttribute("accountno"));
		Long accountno=(Long)session.getAttribute("accountno");
		List<Transactions> detailedTransactionList=userService.getDetailedTransactions(accountno, fromDate, toDate);
		model.addAttribute("detailedTransactionList",detailedTransactionList);
		return "pages/DetailedTransactions";
	}

	@RequestMapping("UpdateProfile")
	public void  getUpdateProfilePage(Model model)
	{
		
	}
	@RequestMapping("trackRequest")
	public String getViewCustomerPage()
	{
		return "ShowServiceTrack" ;
	}
	
	@RequestMapping(value="processGetServiceTrack.do" , method=RequestMethod.POST)
	public String processViewDetails(@RequestParam("requestId") int id , Model model)
	{
		ServiceTracker tracker = null ;
		try
		{
			tracker = userService.getRequestedServiceList(id) ;
			System.out.println(tracker);
		}
		catch(Exception e)
		{
			
			model.addAttribute("errMsg", "Something went wrong while service tracking reason " + e.getMessage()) ;
			return "ErrorPage" ;
		}
		model.addAttribute("tracker", tracker) ;
		return "ShowServiceTrack" ;
	}
	/*@RequestMapping("chqBookRqstSuccess")
	public String getAddCustomerPage(Model model)
	{
		model.addAttribute("services", new ServiceTracker()) ;
		
		return "ChqBookRqstSuccess";
		
	}
	*/
	@RequestMapping(value="processChqBookRqstExist", method=RequestMethod.POST)
	public String processAddChqBookRqst(BindingResult result, Model model,HttpSession serviceIdsession)
	{
		ServiceTracker tracker = null;
		int id=-1;
		try{
		System.out.println("start");
		
		//String accno=(String)session.getAttribute("accountno");
		//Long accountno=Long.parseLong(accno);
		Long accountno=(Long)serviceIdsession.getAttribute("accountno");
		System.out.println(accountno);
		int serviceid=userService.isCheckBookRequestExist(accountno);
		if(serviceid==0)
		{
			
			
			serviceIdsession.setAttribute("serviceId", serviceid);

			
		// String desc=(String)session.getAttribute("Send request");
		String desc = "Cheque Book request";
		System.out.println(desc);
		// long accId=(long)session.getAttribute("123");
					// Date risedDate=(Date)session.getAttribute("2017-09-09");

		// String myDate="09/09/2017";
	
		long millis = System.currentTimeMillis();
		java.sql.Date date = new java.sql.Date(millis);

		System.out.println(date);
		// String status=(String)session.getAttribute("Processing");        
		String status = "Open";

		tracker = new ServiceTracker();

		tracker.setService_Description(desc);
		tracker.setAccount_ID(accountno);
		tracker.setService_Raised_Date(date);
		tracker.setService_Status(status);

		System.out.println(tracker);

		 id = userService.requestService(tracker);

		System.out.println("in ctrl id:" + id);

		model.addAttribute("tracker", id);
		System.out.println(tracker);
		}
		}catch(Exception e)
			{
				e.printStackTrace();
				model.addAttribute("errMsg", "Something went wrong while adding customer reason " + e.getMessage()) ;
				return "ErrorPage" ;
			}
			
			model.addAttribute("message", "Customer added successfully with "+ id ) ;
			return "SuccessPage" ;
	}
	

	@RequestMapping("ProcessUpdateCustomerForm")
	public String processUpdate(@ModelAttribute("customer") @Valid Customer customer, BindingResult result,Model model)
	{
		
		try 
		{
			userService.updateCustomerDetails(customer);
		}
		catch (Exception e)
		{
			
			model.addAttribute("errMsg", "Could Not Update customer details Reason " + e.getMessage()) ;
			return "ErrorPage";
		
		}
		
		model.addAttribute("customer", customer);
		model.addAttribute("message", "customer Updated Successfully");
		

		return "UpdateProfileSuccess";
	}
	
	@RequestMapping("FundTransfer")
	public String getPayeeListPage(Model model,HttpSession session)
	{
		Long accountno=(Long)session.getAttribute("accountno");
		List<Payee> payeeList=userService.getPayee(accountno);
		model.addAttribute("payeeList",payeeList);
		return "pages/FundTransfer";
	}
	
	@RequestMapping("TransactionDetails")
	public String getTransactionDetailsPage(@RequestParam("selectpayee") String payee ,HttpSession session)
	{
		//Long payeeaccount=Long.parseLong(payee);
		session.setAttribute("payeeAccountNo", payee);
		return "pages/FTPay";
	}
	
	@RequestMapping("ProcessTransaction")
	public String processTransaction(@RequestParam("txtAmount")double transactionamount,@RequestParam("txtPwd") String transactionPwd,HttpSession session,Model model )
	{
		
		
		//String payeeacc=(String)session.getAttribute("payeeAccountNo");
		String payeeaccountnos =(String) session.getAttribute("payeeAccountNo");
		System.out.println("string in "+payeeaccountnos);
		
		Long payeeaccountno = Long.parseLong(payeeaccountnos);
		System.out.println("Long convert"+payeeaccountno);
		
		Long accountno=(Long)session.getAttribute("accountno");
		System.out.println("acc no"+accountno);
//		Long accountno=Long.parseLong(acc);
				//Long.parseLong(acc);
		Users user=null;
		Transactions transaction=null;
		FundTransfer transferInfo=null;
		
		int customerid=(int)userService.getCustomerId(accountno);
		System.out.println("in cid"+customerid);
		AccountMaster accountMaster=null;
		AccountMaster payeeaccountMaster=null;
		System.out.println("customer id:"+customerid);
		//int userid = (int) session.getAttribute("userid");
		int userid=(int)session.getAttribute("userid");
		//int userid=Integer.parseInt(id);
		System.out.println("userid"+userid);
		
		user=userService.getUser(userid);
		AccountMaster account=userService.getAccount(accountno);
		System.out.println("inasgvh:"+account);
		System.out.println(user);
		System.out.println(transactionPwd+"="+user.getTransPassword());
		if(transactionPwd.equalsIgnoreCase(user.getTransPassword()))
		{
			System.out.println("password valid");
			System.out.println("acc"+account.getAccountBalance());
			if(account.getAccountBalance()>transactionamount)
			{
				System.out.println("in transaction success");
				Double balance=account.getAccountBalance();
				Double updatedBalance=balance-transactionamount;
				System.out.println();
				payeeaccountMaster=userService.getAccount(payeeaccountno);
				System.out.println("payee acc s"+payeeaccountMaster);
				Double payeebalance=payeeaccountMaster.getAccountBalance();
				Double updatedPayeeBalance=payeebalance+transactionamount;
				
				
				 long millis=System.currentTimeMillis();  
			     java.sql.Date date=new java.sql.Date(millis);  
				 
			     transferInfo=new FundTransfer();
			      transferInfo.setAccount_Id(accountno); 
			      transferInfo.setDateOfTransfer(date);
			      transferInfo.setPayee_Account(payeeaccountno);
			      transferInfo.setTransferAmount(transactionamount);
			      
			      System.out.println(transferInfo);
			      
			      transaction=new Transactions();
			      transaction.setAccountID(accountno);
			      transaction.setDateOfTransaction(date);
			      transaction.setTran_Description("Fund Transfer");
			      transaction.setTransactionAmount(transactionamount);
			      transaction.setTransactionType('T');
				
			      System.out.println(transaction);
			      accountMaster=userService.getAccount(accountno);
			      accountMaster.setAccountBalance(updatedBalance);
			      
			      payeeaccountMaster.setAccountBalance(updatedPayeeBalance);
			      
			      System.out.println("ft");
				userService.fundTransfer(transferInfo);
				System.out.println("it");
				userService.insertTransaction(transaction);
				System.out.println("upd");
				userService.updateBalance(accountMaster);
				
				userService.updateBalance(payeeaccountMaster);
				System.out.println("transaction cmpltd");
				
					return "pages/FTSuccess";
				
			}
			else
			{
				model.addAttribute("errMsg",
						"Not Sufficient Balance");
				return "pages/FTPay";				}
		}
		else
		{
			model.addAttribute("errMsg",
					"Wrong Transaction Password");
		return "/pages/FTPay.jsp";
		}

		
		/*if(userService.getUser())*/
		
	}
	
	
	
}

	

